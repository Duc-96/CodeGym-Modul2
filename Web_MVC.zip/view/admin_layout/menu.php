<div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">Quản Lý</div>
                            <a class="nav-link" href="./index.php?controller=user&action=list&page=1">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                Người Dùng
                            </a>
                            <a class="nav-link" href="./index.php?controller=product&action=list&page=1">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                Sản Phẩm
                            </a>
                        </div>
                    </div>
                    <div class="sb-sidenav-footer">
                        <div class="small">Admin</div>
                    </div>
                </nav>
            </div>